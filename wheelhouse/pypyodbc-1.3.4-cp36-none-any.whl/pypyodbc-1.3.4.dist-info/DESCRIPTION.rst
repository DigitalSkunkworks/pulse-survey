A Pure Python ctypes ODBC module compatible with PyPy and almost totally same usage as pyodbc


